﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PackPile : MonoBehaviour
{
    public void PointerDown()
    {
        CursorPack.Instance.PickUp();
    }
}
