﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PackOpener : MonoBehaviour
{
    public static PackOpener Instance;
    public Sprite cardBack;
    public List<Card> allCards;
    List<Card> commonCards = new List<Card>();
    List<Card> rareCards = new List<Card>();
    List<Card> epicCards = new List<Card>();
    List<Card> legendaryCards = new List<Card>();
    public List<GameObject> floatingCards;
    public Card[] currentCards = new Card[5];

    public GameObject doneButton;
    int cardsFlipped;

    public void Awake()
    {
        Instance = this;

        foreach (Card card in allCards)
        {
            if(card.rarity == Rarity.Common)
            {
                commonCards.Add(card);
            }
            else if(card.rarity == Rarity.Rare)
            {
                rareCards.Add(card);
            }
            else if(card.rarity == Rarity.Epic)
            {
                epicCards.Add(card);
            }
            else if(card.rarity == Rarity.Legendary)
            {
                legendaryCards.Add(card);
            }
        }
    }

    public void OpenPack()
    {
        GetComponent<Animator>().SetTrigger("open");
        for (int i = 0; i < 5; i++)
        {
            int cardRarity = Random.Range(0, 4);
            if(cardRarity == 0)
            {
                AssignCard(i, commonCards[Random.Range(0, commonCards.Count)]);
                floatingCards[i].transform.GetChild(0).GetComponent<Image>().color = Color.white;
            }
            else if(cardRarity == 1)
            {
                AssignCard(i, rareCards[Random.Range(0, rareCards.Count)]);
                floatingCards[i].transform.GetChild(0).GetComponent<Image>().color = Color.blue;
            }
            else if(cardRarity == 2)
            {
                AssignCard(i, epicCards[Random.Range(0, epicCards.Count)]);
                floatingCards[i].transform.GetChild(0).GetComponent<Image>().color = new Color(103, 37, 153);
            }
            else if(cardRarity == 3)
            {
                AssignCard(i, legendaryCards[Random.Range(0, legendaryCards.Count)]);
                floatingCards[i].transform.GetChild(0).GetComponent<Image>().color = new Color(255, 115, 0);
            }
        }
    }


    public void AssignCard(int index, Card card)
    {
        if(index >= 0 && index < 5)
        {
            currentCards[index] = card;
            floatingCards[index].GetComponent<FloatingCard>().card = card;
            floatingCards[index].SetActive(true);
        }
    }

    public void FlipCard()
    {
        cardsFlipped++;
        if(cardsFlipped == 5)
        {
            ShowDoneButton();
        }
    }

    void ShowDoneButton()
    {
        doneButton.SetActive(true);
    }

    public void DoneButtonClick()
    {
        doneButton.SetActive(false);
        cardsFlipped = 0;
        GetComponent<Animator>().SetTrigger("done");

        for (int i = 0; i < 5; i++)
        {
            floatingCards[i].transform.GetChild(1).GetComponent<Image>().sprite = cardBack;
            floatingCards[i].SetActive(false);
            floatingCards[i].GetComponent<Animator>().SetTrigger("done");
        }
    }
}
