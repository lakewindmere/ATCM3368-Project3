﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PackOpenZone : MonoBehaviour
{
    public static PackOpenZone Instance;

    bool packInZone = false;
    public Image zonePack;

    public AudioSource audioSource;

    void Start()
    {
        Instance = this;
    }

    public void OnEnter()
    {
        CursorPack.Instance.onZone = true;
    }

    public void OnExit()
    {
        CursorPack.Instance.onZone = false;
    }

    public void OnPointerUp()
    {
        packInZone = true;
        zonePack.enabled = true;
        GetComponent<Animator>().SetTrigger("hasPack");
    }

    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Space) && packInZone)
        {
            StartOpenPack();
            audioSource.Play();
        }
    }

    void StartOpenPack()
    {
        GetComponent<Animator>().SetTrigger("open");
        Invoke("OpenPack", 1.3f);
    }

    void OpenPack()
    {
        PackOpener.Instance.OpenPack();
        packInZone = false;
        zonePack.enabled = false;
    }
}
