﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CursorPack : MonoBehaviour
{
    public static CursorPack Instance;

    public AudioSource audioSource;

    public GameObject packGraphic;
    public bool packHeld;
    [HideInInspector]public bool onZone;

    void Start()
    {
        Instance = this;
    }

    public void Drop()
    {
        packHeld = false;
        packGraphic.SetActive(false);
    }

    public void PickUp()
    {
        packHeld = true;
        packGraphic.SetActive(true);
        audioSource.Play();
    }

    public void Update()
    {
        transform.position = Vector3.Lerp(transform.position, Input.mousePosition, Time.deltaTime * 10f);
        

        if(Input.GetKeyUp(KeyCode.Mouse0))
        {
            if(onZone)
            {
                PackOpenZone.Instance.OnPointerUp();
            }
            Drop();
        }
    }
}
