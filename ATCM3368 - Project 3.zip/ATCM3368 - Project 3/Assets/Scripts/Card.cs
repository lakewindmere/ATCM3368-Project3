﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum Rarity { Common, Rare, Epic, Legendary};
[CreateAssetMenu(fileName = "Card", menuName = "Card", order = 1)]
public class Card : ScriptableObject
{
    public Sprite cardFront;
    public Rarity rarity;
}
