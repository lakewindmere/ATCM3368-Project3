﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FloatingCard : MonoBehaviour
{
    public Card card;
    public Image image;

    public AudioSource hoverAudio;
    public AudioSource turnAudio;
    

    public void PointerEnter()
    {
        GetComponent<Animator>().SetBool("hovering", true);
        hoverAudio.Play();
    }

    public void PointerExit()
    {
        GetComponent<Animator>().SetBool("hovering", false);
    }

    public void OnClick()
    {
        PackOpener.Instance.FlipCard();    
        GetComponent<Animator>().SetTrigger("turn");
        Invoke("SpriteSwap", 0.25f);
        turnAudio.Play();
    }

    void SpriteSwap()
    {
        image.sprite = card.cardFront;
    }
}
